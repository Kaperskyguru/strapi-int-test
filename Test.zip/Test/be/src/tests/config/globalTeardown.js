module.exports = async () => {
  await global.httpServer.stop();
};
