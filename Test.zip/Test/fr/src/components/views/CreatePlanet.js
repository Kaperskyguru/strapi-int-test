
import PlanetModal from '../PlanetModal';
import useStyles from '../../style'


const Planet = () => {
    const classes = useStyles();
    return (
        <>
            <PlanetModal  />
        </>
    )
}

export default Planet