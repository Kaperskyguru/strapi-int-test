import React from "react";
import AddCharacter from "./modals/AddCharacter";

function CharacterModal() {
  return (
    <>
      <AddCharacter />
    </>
  );
}

export default CharacterModal;
