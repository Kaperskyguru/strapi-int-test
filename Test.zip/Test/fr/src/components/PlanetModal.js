import React from 'react';
import AddPlanet from './modals/AddPlanet'

function PlanetModal() {

    return (
        <>
            <AddPlanet />
        </>
    )
}

export default PlanetModal;
